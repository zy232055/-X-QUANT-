package com.dfitc.stpe89a8f39d67e.strategy.baseStrategy;

import com.dfitc.stp.annotations.*;
import com.dfitc.stp.indicator.*;
import com.dfitc.stp.market.*;
import com.dfitc.stp.trader.*;
import com.dfitc.stp.strategy.*;
import com.dfitc.stp.entity.Time;
import com.dfitc.stp.util.BarsUtil;
import com.dfitc.stp.util.DoubleSeries;
import com.dfitc.stp.util.StringUtil;
import java.util.Date;



/**
  *策略描述:
  *	1. 在今天的收盘，计算两个值：最高价－收盘价，和收盘价－最低价。然后取这两个值较大的那个，乘以k值0.7。把结果称为触发值。

  *	2. 在明天的开盘，记录开盘价，然后在价格超过（开盘＋触发值）时马上买入，或者价格低于（开盘－触发值）时马上卖空。

  *	3. 没有明确止损。这个系统是反转系统，也就是说，如果在价格超过（开盘＋触发值）时手头有一口空单，则买入两口。同理，如果在价格低于（开盘－触发值）时手上有一口多单，则卖出两口。
  *	Dual Thrust在开盘区间突破策略上进行了相关改进：
  *	1、在范围（range）的设置上，引入前N日的四个价位，使得一定时期内的范围相对稳定，可以适用于日间的趋势跟踪；
  *	2、Dual Thrust对于多头和空头的触发条件，考虑了非对称的幅度，做多和做空参考的Range可以选择不同的周期数，也可以通过参数K1和K2来确定。当K1时，多头相对容易被触发,当K1>K2时，空头相对容易被触发。
  *	因此，在使用该策略时，一方面可以参考历史数据测试的最优参数，另一方面，则可以根据自己对后势的判断，或从其他大周期的技术指标入手，阶段性地动态调整K1和K2的值。
  *	就是一个典型的观望、等待信号、进场、套利、离场的套路，却效果卓著。
  * @author 张宇  zhangyuchnqd@163.com
  * 2015-08-07
  */
	
	
@Strategy(name = "DualTHrust",version="1.0",outputMode = OutputMode.TIMER, outputPeriod = 3000, contractNumber = 1)
public class DualTHrust extends BaseStrategy {
	/**
	 * 参数描述:
	 */

	@In(label = "前n日价位", sequence = 1)
	@Text(value = "5", readonly = false)
	int n;
	
	/**
	 * 参数描述:
	 */

	@In(label = "上轨系数", sequence = 1)
	@Text(value = "0.7", readonly = false)
	double k1;
	
	/**
	 * 参数描述:
	 */

	@In(label = "下轨系数", sequence = 2)
	@Text(value = "0.7", readonly = false)
	double k2;
	
	/**
	 * 参数描述:
	 */

	@In(label = "开仓手数", sequence = 3)
	@Text(value = "1", readonly = false)
	int vol;
	
	

	@In(label = "尾盘强制出场时间", sequence = 4)
	@DateTime(value = "14:55:00", format = "HH:mm:ss", style = Style.TIME)
	Time exitTime;
	
	DoubleSeries highPriceSeries = new DoubleSeries();
	DoubleSeries lowPriceSeries = new DoubleSeries();
	DoubleSeries closePriceSeries= new DoubleSeries();
	double lastDayOpenPrice = 0;
	BarsUtil barsUtil = new BarsUtil(100);
	/** 
 * 参数描述:HH:=hhv(昨高,n);//N日high的最高价
 * HC:=hhv(昨收,n);//N日close的最高价
 * LC:=LLV(昨收,n);//N日close的最低价
 * LL:=LLV(昨低,n);//N日low的最低价
 */
	double hh = 0;
	double hc = 0;
	double lc = 0;
	double ll = 0;
	/** 
 * 参数描述: 浮动区间
 */
	double range = 0;

	
 	/**
	 
 * 初始化K线周期，在策略创建时被调用(在initialize之后调用)		
 * @param contracts策略相关联的合约
	 */
	@Override
	public void setBarCycles(String[] contracts) {
		 importBarCycle(contracts[0], Unit.MINUTE, 1);
	}

	/**
	 
 * 初始化指标，在策略创建时被调用(在initialize之后调用)		
 * @param contracts策略相关联的合约
	 */
	@Override
	public void setIndicators(String[] contracts) {
		
	}
	
	/**
	 * 初始化方法，在策略创建时调用
	 * 
	 * @param contracts
	 *            策略关联的合约
	 */
	@Override
	public void initialize(String[] contracts) {
		this.setAutoPauseBySystem(false);
		this.setAutoResumeBySystem(false);
		this.setAutoPauseByLimit(false);
		this.setExitOnClose(exitTime);
	}
	/**
	 * 处理K线
	 * 
	 * @param bar
	 *            触发此次调用的K线
	 * @param barSeries
	 *            此次K线所对应的K线序列(barSeries.get()与bar是等价的)
	 */
	public void processBar(Bar bar, BarSeries barSeries) {
			barsUtil.update(barSeries);
		//System.out.println("barsUtil.openD(0) " + barsUtil.openD(0));
			if (barsUtil.openD(0) != lastDayOpenPrice){
			lastDayOpenPrice = barsUtil.openD(0);
			highPriceSeries.add(barsUtil.highD(1));
			lowPriceSeries.add(barsUtil.lowD(1));
			closePriceSeries.add(barsUtil.closeD(1));
			if(highPriceSeries.size() <= n){
				System.out.println("return");
				return;
			}
			hh = highPriceSeries.head(n).max();
			hc = closePriceSeries.head(n).max();
			lc = closePriceSeries.head(n).min();
			ll = lowPriceSeries.head(n).min();
			range = Math.max(hh - hc, lc - ll);
			System.out.println("range " + range);
		}
			if(highPriceSeries.size() <= n){
				System.out.println("return");
				return;
			}
		/**
		 * 突破上轨开多，突破下轨开空,如果在价格超过（开盘＋触发值）时手头有一口空单，则买入两口。
		 * 同理，如果在价格低于（开盘－触发值）时手上有一口多单，则卖出两口。
		 */
		if(getDirPositionVol(1) == 0){
			
			if(bar.getClose() > barsUtil.openD(0) + k1 * range){
				if(getDirPositionVol(-1) == 0){
					buy(vol);
					System.out.println("getDirPositionObject().getDirPosition(1) " + getDirPositionVol(1));
				}
				else{
					buy(2 * getDirPositionVol(-1));
					System.out.println("getDirPositionObject().getDirPosition(1) " + getDirPositionVol(1));
				}
			}
		}
		if(getDirPositionVol(-1) == 0){
			if(bar.getClose() < barsUtil.openD(0) - k2 * range){
				if(getDirPositionVol(1) == 0){
					sell(vol);
				}
				else{
					sell(2 * getDirPositionVol(1));
				}
			}
		}
		
	}
	
	
	
}
