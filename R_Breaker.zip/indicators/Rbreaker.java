package com.dfitc.stpe89a8f39d67e.indicator.baseIndicator;

import com.dfitc.stp.annotations.*;
import com.dfitc.stp.indicator.BarIndicator;
import com.dfitc.stp.market.*;
import com.dfitc.stp.util.BarsUtil;


/** 
 * 指标类型:.
 * 指标描述:
 */

public class Rbreaker extends BarIndicator {
	/**
	 * 参数描述:
	 */
	double f1 = 0.35;
	double f2 = 0.07;
	double f3 = 0.25;
	double bBreak=0;
	double sSetup=0;
	double sEnter=0;
	double bEnter=0;
	double bSetup=0;
	double sBreak=0;
	double lastDayOpenPrice=0;
	BarsUtil barsUtil=new BarsUtil(100);
	public Rbreaker (double f1,double f2, double f3) {
		super(f1, f2, f3);
		this.f1 = f1;
		this.f2 = f2;
	 	this.f3 = f3;
	}
	
	/** 
	 * 指标计算回调函数，在每个K线到达时被调用(收盘价调用)
	 * @param bar 当前获得的最新K线
	 * @param barSeries 到目前为止的K线序列
	 * @param results 指标的多个值(数组的长度与initIndicatorNum()一致，内容是上一次计算的值，如果是第一次计算，则里面的所有值为0)
	 */
	public void calculateBar(Bar bar, BarSeries barSeries, double[] results) {
		barsUtil.update(barSeries);
		if (barsUtil.openD(0) != lastDayOpenPrice) {
			lastDayOpenPrice = barsUtil.openD(0);
			sSetup = barsUtil.highD(1) + f1
					* (barsUtil.closeD(1) - barsUtil.lowD(1));
			sEnter = ((1 + f2) / 2) * (barsUtil.highD(1) + barsUtil.lowD(1))
					- f2 * barsUtil.lowD(1);
			bEnter = ((1 + f2) / 2) * (barsUtil.highD(1) + barsUtil.lowD(1))
					- f2 * barsUtil.highD(1);
			bSetup = barsUtil.lowD(1) - f1
					* (barsUtil.highD(1) - barsUtil.closeD(1));
			;
			bBreak = sSetup + f3 * (sSetup - bSetup);
			sBreak = bSetup - f3 * (sSetup - bSetup);
		}
		results[0] = sSetup;
		results[1] = sEnter;
		results[2] = bEnter;
		results[3] = bSetup;
		results[4] = bBreak;
		results[5] = sBreak;
		System.out.println(bBreak + " " + sSetup + " " + sEnter
				 + " " + bEnter + " " + bSetup + " " + sBreak);
	}
	public boolean preCalculateBar(Bar bar, BarSeries barSeries,
			double[] results) {
		return true;
	}
	@Override
	public String[] initIndicatorNames() {
		return new String[] { "sSetup", "sEnter", "bEnter", "bSetup", "bBreak", "sBreak"};
	}
	@Override
	public int initIndicatorNum() {
		return 6;
	}	
}