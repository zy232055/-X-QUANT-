package com.dfitc.stpe89a8f39d67e.strategy.baseStrategy;

import com.dfitc.stp.annotations.*;
import com.dfitc.stp.indicator.*;
import com.dfitc.stp.market.*;
import com.dfitc.stp.trader.*;
import com.dfitc.stp.strategy.*;
import com.dfitc.stp.entity.Time;
import com.dfitc.stp.util.DoubleSeries;
import com.dfitc.stp.util.IndicatorUtil;
import com.dfitc.stp.util.Series;
import com.dfitc.stp.util.StringUtil;
import java.util.Date;

import com.dfitc.stpe89a8f39d67e.indicator.baseIndicator.ATR;
import com.dfitc.stpe89a8f39d67e.indicator.baseIndicator.MA;


/**
  *策略描述:肯特纳通道( Keltner Channel)：肯特纳通道是基于平均真实波幅原理而形成的指标，对价格波动反应灵敏，它可以取代布林线或百分比通道 (Percentage Envelopes) 作为判市的新工具。肯特纳通道是由两根围绕线性加权移动平均线波动的环带组成的，通常线性加权均线的参数是 20 。
价格突破带状的上轨和下轨时，通常会产生做多或做空的交易信号。
  *@author 张宇 2015-08-5 zhangyuchnqd@163.com
  */
	
	
@Strategy(name = "凯特纳通道",version="1.0",outputMode = OutputMode.TIMER, outputPeriod = 3000, contractNumber = 1)
public class KeltnerChannel extends BaseStrategy {
	/**
	 * 参数描述:
	 */

	@In(label = "length", sequence = 0)
	@Text(value = "20", readonly = false)
	int length;
	
	/**
	 * 参数描述:
	 */

	@In(label = "numATRs", sequence = 1)
	@Text(value = "1.5", readonly = false)
	double numATRs;
	
	

	@In(label = "止盈系数", sequence = 2)
	@Text(value = "0.2", readonly = false)
	double percentTrailing;
	
	

	@In(label = "止损（几个最小变动价位）", sequence = 3)
	@Text(value = "5", readonly = false)
	int stopLoss;
	
	

	@In(label = "止盈线", sequence = 4)
	@Text(value = "100.0", readonly = false)
	double stopProfitLine;
	
	

	@In(label = "开仓手数", sequence = 5)
	@Text(value = "1", readonly = false)
	int vol;
	
	@Out
	MA ma;
	@Out
	ATR atr;
	boolean lock=false;
	double maxProfit=0;
	int buyOpen=0;
	int sellOpen=0;
	double maxLine = 0;
	DoubleSeries mdSeries = new DoubleSeries(20);
	DoubleSeries highSeries = new DoubleSeries(20);
	DoubleSeries lowSeries = new DoubleSeries(20);
 	/**
	 
 * 初始化K线周期，在策略创建时被调用(在initialize之后调用)				
 * @param contracts策略相关联的合约
	 */
	@Override
	public void setBarCycles(String[] contracts) {
	}

	/**
	 
 * 初始化指标，在策略创建时被调用(在initialize之后调用)				
 * @param contracts策略相关联的合约
	 */
	@Override
	public void setIndicators(String[] contracts) {
		ma = (MA)this.importIndicator(new MA(length), contracts[0], Unit.MINUTE, 3);
		this.ma.setIndicatorNames(new String[] { "ma" });
		atr = (ATR)this.importIndicator(new ATR(length), contracts[0], Unit.MINUTE, 3);
		this.atr.setIndicatorNames(new String[] { "atr" });
		
	}
	
	/**
	 * 初始化方法，在策略创建时调用
	 * 
	 * @param contracts
	 *            策略关联的合约
	 */
	@Override
	public void initialize(String[] contracts) {
		this.setAutoPauseBySystem(false);
		this.setAutoResumeBySystem(false);
		this.setAutoPauseByLimit(false);
	}
	/**
	 * 处理K线
	 * 
	 * @param bar
	 *            触发此次调用的K线
	 * @param barSeries
	 *            此次K线所对应的K线序列(barSeries.get()与bar是等价的)
	 */
	public void processBar(Bar bar, BarSeries barSeries) {
	}
	
	
	@Override
	public void processMD(MD md) {
		
	  if (ma.getSubIndicatorResult() == 0.0) {
	    return;
	  }
	  mdSeries.add(md.getLatestPrice());
	  double highLine = ma.getSubIndicatorResult() + numATRs * atr.getSubIndicatorResult();
	  double lowLine = ma.getSubIndicatorResult() - numATRs * atr.getSubIndicatorResult();
	  highSeries.add(highLine);
	  lowSeries.add(lowLine);
	  if(!highSeries.isFull()){
		  return;
	  }
	  //System.out.println(atr.getSubIndicatorResult());
	  //凯特那通道
	  if (IndicatorUtil.crossUp(mdSeries, highSeries) && !lock) {
	    buyToOpen(vol);
	    buyOpen = vol;
	    lock=true;
	  }
	 else if (IndicatorUtil.crossDown(mdSeries, lowSeries) && !lock) {
	    sellToOpen(vol);
	    sellOpen = vol;
	    lock=true;
	  }
	  if (lock) {
	    double profit=0;
	    if (buyOpen != 0)     profit=getDirPositionProfit(1);
	 else     profit=getDirPositionProfit(-1);
	    //止盈
	    if (profit > 0) {
	      if (profit > maxProfit)       maxProfit=profit;
	 else       if (profit < maxProfit * (1 - percentTrailing) && maxProfit > stopProfitLine) {
	        if (getDirPositionVol(1) != 0)         sellToClose(vol);
	        if (getDirPositionVol(-1) != 0)         buyToClose(vol);
	        lock=false;
	        maxProfit=0;
	        buyOpen=0;
	        sellOpen=0;
	      }
	    }
	    //止损
	 else     if (profit < 0) {
	      if (getDirPositionVol(1) != 0 && md.getLatestPrice() <= getDirPositionAvgPrice(1) - stopLoss * getMinMove()) {
	    	 // System.out.println(getDirPositionAvgPrice(1));
	        sellToClose(vol);
	        lock=false;
	        maxProfit=0;
	        buyOpen=0;
	      }
	 else       if (getDirPositionVol(-1) != 0 && md.getLatestPrice() >= getDirPositionAvgPrice(-1) + stopLoss * getMinMove()) {
	        buyToClose(vol);
	        lock = false;
	        maxProfit = 0;
	        sellOpen = 0;
	      }
	    }
	  }
	
		}
		
		
}
