package com.dfitc.stpe89a8f39d67e.indicator.baseIndicator;

import com.dfitc.stp.indicator.BarIndicator;
import com.dfitc.stp.market.Bar;
import com.dfitc.stp.market.BarSeries;
import com.dfitc.stp.util.DoubleSeries;
import com.dfitc.stp.util.IndicatorUtil;

/**
 * 指标类型:指标样例. 指标描述: ATR指标<br>
 * 公式参考:T R = MAX((HIGH-LOW),ABS(CLOSE[1]-HIGH),ABS(CLOSE[1]-LOW))<br>
 * ATR = MA(TR,N)<br>
 */
public class ATR extends BarIndicator {
	private int n;
	private DoubleSeries x;
	private TR tr = new TR();

	/**
	 * 构造函数(指标所需参数取默认值14)
	 */
	public ATR() {
		this(14);
	}

	/**
	 * 构造函数
	 * 
	 * @param n
	 *            计算ATR所需要的TR值的个数
	 */
	public ATR(int n) {
		super(n);
		this.n = n;
		this.x = new DoubleSeries(n + 1);// 注意：为了在第1次计算MA之后能快速计算MA，需要数组的长度为n+1
	}

	@Override
	public boolean preCalculateBar(Bar bar, BarSeries barSeries, double[] results) {
		if (tr.isPreCalculated()) {
			x.add(tr.getSubIndicatorResult());
		}
		return x.isFull();
	}

	@Override
	public void calculateBar(Bar bar, BarSeries barSeries, double[] results) {
		if (isCalculated()) {
			// 如果不是第1次计算则采用快速算法：(lastMA*N-X[N]+X[0])/N
			results[0] = IndicatorUtil.ma(x, n, results[0]);
		} else {
			// 第1次计算
			results[0] = IndicatorUtil.ma(x, n);
		}
	}

	/**
	 * 获取TR指标的历史数据序列
	 * 
	 * @return 历史数据序列
	 */
	public DoubleSeries getTrseries() {
		return x;
	}

}
