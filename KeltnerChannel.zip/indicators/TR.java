package com.dfitc.stpe89a8f39d67e.indicator.baseIndicator;

import com.dfitc.stp.indicator.BarIndicator;
import com.dfitc.stp.market.Bar;
import com.dfitc.stp.market.BarSeries;
import com.dfitc.stp.util.MathUtil;

/**
 * 指标类型:指标样例. 指标描述: TR指标(在计算ATR指标时使用)<br>
 * 公式参考:TR = MAX((HIGH-LOW),ABS(CLOSE[1]-HIGH),ABS(CLOSE[1]-LOW))<br>
 */
public class TR extends BarIndicator {

	@Override
	public boolean preCalculateBar(Bar bar, BarSeries barSeries, double[] results) {
		return barSeries.size() >= 2;
	}

	@Override
	public void calculateBar(Bar bar, BarSeries barSeries, double[] results) {
		// TR = MAX((HIGH-LOW),ABS(CLOSE[1]-HIGH),ABS(CLOSE[1]-LOW))
		double a = barSeries.high() - barSeries.low();
		double b = MathUtil.abs(barSeries.close(1) - barSeries.high());
		double c = MathUtil.abs(barSeries.close(1) - barSeries.low());
		results[0] = MathUtil.max(a, b, c);
	}

}
